from django.contrib import admin

# Register your models here.

from homepage.models import Author, Article, Theme

admin.site.register(Article)
admin.site.register(Author)
admin.site.register(Theme)
