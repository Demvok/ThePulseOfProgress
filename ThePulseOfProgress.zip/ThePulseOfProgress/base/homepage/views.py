from django.shortcuts import render

# Create your views here.

dict_template = {
    'footer': {'text': 'Пульс прогресу © 2023', 'link': 'Про нас'},
}

from homepage.models import Article, Theme, Author

def homepage(request):
    d = dict_template.copy()
    Article.objects.order_by('-date')
    d.update({
            'title': 'Пульс прогресу',
            'hotNews': Article.objects.filter(hot=True)})
    return render(request, 'home.html', d)

def politics(request):
    d = dict_template.copy()
    d.update({
            'title': 'Політика',
            'news': Article.objects.filter(
        theme__name= 'Politics'
    )})
    return render(request, 'news-categories.html', d)

def finances(request):
    d = dict_template.copy()
    d.update({
            'title': 'Фінанси',
            'news': Article.objects.filter(
        theme__name= 'Finances'
    )})
    return render(request, 'news-categories.html', d)

def sports(request):
    d = dict_template.copy()
    d.update({
            'title': 'Спорт',
            'news': Article.objects.filter(
        theme__name= 'Sports'
    )})
    return render(request, 'news-categories.html', d)

def weather(request):
    d = dict_template.copy()
    d.update({
            'title': 'Погода',
            'news': Article.objects.filter(
        theme__name= 'Weather'
    )})
    return render(request, 'news-categories.html', d)

def info(request):
    d = dict_template.copy()
    d.update({
            'title': 'Про нас',
    })
    return render(request, 'info.html', d)

def article(request, id):
    d = dict_template.copy()
    d.update({'article': Article.objects.get(id=id),
              'filling': Article.objects.get(id=id).text.read().decode('utf-8'),
              'imageHere': Article.objects.get(id=id).headImage.url
              })
    return render(request, 'article.html', d)