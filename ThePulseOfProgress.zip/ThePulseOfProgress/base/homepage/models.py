from django.db import models

# Create your models here.

class Theme(models.Model):
    name = models.CharField(max_length=128)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name

class Author(models.Model):
    shortName = models.CharField(max_length=128)
    name = models.CharField(max_length=128, null=True, blank=True)
    surname = models.CharField(max_length=128, null=True, blank=True)
    initials = models.CharField(max_length=128, null=True, blank=True)

    def __str__(self):
        return self.shortName

class Article(models.Model):
    name = models.CharField(max_length=256)
    summary = models.TextField(null=True, blank=True)
    headImage = models.ImageField(upload_to='images', null=True)
    text = models.FileField(upload_to='articles')
    author = models.ForeignKey(to=Author, on_delete=models.PROTECT, null=True, blank=True)
    date = models.DateTimeField(null=True, blank=True)
    theme = models.ForeignKey(to=Theme, on_delete=models.PROTECT, related_name='theme')
    hot = models.BooleanField(default=False, null=True, blank=True)

    def __str__(self):
        return f'ID: {self.id} {self.name}{["", " HOT"][self.hot]}'
